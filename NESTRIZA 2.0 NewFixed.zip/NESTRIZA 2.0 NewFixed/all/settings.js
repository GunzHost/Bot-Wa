//SCRIPT NESTRIZA 2.0
//CREATOR : ERIZA DEVELOPMENT
//JANGAN HAPUS BAGIAN INI !!!

require("./module")

global.owner = "48459261212" //PAKE NO LU BIAR BISA ADD AKSES
global.namabot = "Cyaa Botz" //NAMA BOT GANTI
global.botnumber = "48459261212" //ISI PAKE NO YG MAU DIJADIIN BOT
global.namaCreator = "Cyaa Development" //NAMA CREATOR GANTI AJA
global.teksmenu = "`CARA PENGGUNAAN`\n===> _ikuti langkah berikut_\n\n- Ketik .listgc *untuk melihat id dan status grup*\n- Ketik .save *untuk save kontak nomor yg di chat*\n- Ketik .pushkontak *untuk push di gc terbuka*\n- Ketik .pushkontak2 *untuk push di gc tertutup*\n\n`CARA PUSHKONTAK`\n==> _Grup Terbuka_\n\n1. Lakukan Format Berikut : *.pushkontak pesan|jeda*\n2. Cara pengisian : *.pushbuka sv eriza|10000*\n3. Note : *Untuk jedanya, 1000 = 1detik* , Biasanya gw pakai 10000 alias 10detik\n4. Lakukan Rangkaian berikut di dalam grup yg ingin di push\n\n`CARA PUSHKONTAK`\n==> _Grup Tertutup_\n\n1. Ketik *.listgc* untuk mengetahui id grup yg di tuju\n2. isi format berikut *.pushkontak id|pesan|jeda*\n3. Contoh pengisian: *.pushkontak2 12273737338387@g.us|sv eriza|10000*\n4. Note : *Untuk jedanya, 1000 = 1detik* , Biasanya gw pakai 10000 alias 10detik\n5. Lakukan Rangkaian berikut melalui private chat\n\n*TERIMAKASIH TELAH ORDER BOT PUSHKONTAK KAMI*\n`script ini masih dalam tahap pengembangan`"
global.nodana = "083845460282" //GANTI PAKE NOMOR DANA LU
global.nogopay = "-" //GANTI PAKE NOMOR GOPAY LU
global.noovo = "-"
//GANTI PAKE NOMOR OVO LU
global.qris = "https://telegra.ph/file/628c33d330542c275e945.jpg"
//ISI PAKAI QRIS LU MENGGUNAKAN LINK TELEGRA PH
global.autoJoin = false //NOT CHANGE / JANGAN GANTI
global.antilink = false //NOT CHANGE / JANGAN GANTI
global.versisc = 'NestRiza 2.0' //NOT CHANGE / JANGAN GANTI
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.domain = 'https://' //ISI DOMAIN SERVER PANEL LU
global.apikey = 'ptla' //ISI APIKEY PTLA LU
global.capikey = 'ptlc' //ISI APIKEY PTLC LU
global.eggsnya = '15' //PAKE ID EGGS MU KALO GA TAU DEFAULT AJA
global.location = '1' //JANGAN DIGANTI KALO G MAU EROR

global.imageurl = 'https://telegra.ph/file/e0369e556aa06cbe8b67e.jpg' //GANTI PP MU MENGGUNAKAN LINK TELEGRA PH
global.isLink = 'https://chat.whatsapp.com/KQPqjAt2eQP0IaA0ALdXu2' ///GANTI MENGGUNAKAN LINK GRUBMU YA
global.chsaluran = 'https://chat.whatsapp.com/KQPqjAt2eQP0IaA0ALdXu2' //GANTI PAKE LINK SALURAN WA LU
global.thumb = fs.readFileSync("./thumb.png") ///NOT CHANGE / JANGAN GANTI
global.audionya = fs.readFileSync("./all/sound.mp3") //NOT CHANGE / JANGAN GANTI
global.simbol = '⨠' //GANTI AJA BEBAS
global.tekspushkon = "" //NOT CHANGE / JANGAN GANTI
global.tekspushkonv2 = "" //NOT CHANGE / JANGAN GANTI
global.packname = "WhatsApp Bot Official" //GANTI AJ
global.author = "- Cyaa Development" //GANTI SERAH MU
global.jumlah = "5" ////NOT CHANGE / JANGAN GANTI

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})